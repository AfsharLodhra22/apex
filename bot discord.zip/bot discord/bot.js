//======================================================================================
/*
	This is a Dicord Bot for SAMP Servers written in Node.js
	Bot Version: 2.1
	Author: Abhay SV Aka DuskFawn Aka Perfectboy. 
*/
//=======================================================================================

//______________________[Discord JS and SAMP Query Library]______________________________
const Discord = require('discord.js');
const client = new Discord.Client();
var query = require('samp-query');

//_____________________________[BOT Configuration]_________________________________________
//@audit Settings

const botChar = "!"; // Bot prefix character
let Samp_IP = "play.indonex.my.id";
let Samp_Port = 7777;
let Community_Tag ="IDX";

let userToSubmitApplicationsTo = '710195458680684695';//Default Channel Id for User Applications
let reportChannelID = '714432112031170562'; // Channel for the ingam reports
let playerCmdsChannelID = '1054341029005901896';
let adminCmdsChannelID = '1068733223875661924';
let Bot_debug_mode = false;

//_______________________________[APPLICATIONS]______________________________________________
let applicationQuestions = require("./application-questions.js"); //This .js file has the default questions
let usersApplicationStatus = [];
let appNewForm = [];
let isSettingFormUp = false;

//______________________________[SAMP Server MySQL Connection]________________________________
const mysql = require("mysql");
var db = mysql.createConnection({
    host: '149.129.240.43',
    user: 'kontol',
    password: 'asuasu',
    database: 'tes',
});


//_______________________________[BOT Startup]_________________________________________________
//@audit-ok Client Ready
client.on('ready', () => {

    console.log('Dumbledore Woke Up from sleep!');
	console.log(`Logged in as ${client.user.tag}!`);
	//client.user.setActivity('!help play.indonex.my.id ',['address'],{type: "watching"});
	setTimeout(getLastReportId, 1000);
	setInterval(ReportSync, 20000);
	client.user.setPresence({
		activity: {
			name: `!helpme│play.indonex.my.id`,
			type: 'WATCHING'
		},
		status: 'dnd'
	});
});

var last_report = 0;
function getLastReportId()
{
    db.query("SELECT * FROM `whitelist` ORDER BY `wlID`.`wlName` DESC LIMIT 1",
     [], function(err,row) {
		if(row)
		{ 
			last_report = parseInt(row[0].id);
			if(Bot_debug_mode)
				console.log(`[DEBUG]Last Report id:${last_report}`);
		}
		else 
		{
			
		}
	
	});

}

function ReportSync()
{
    db.query(`SELECT * FROM whitelist WHERE id > ${last_report}`,
     [], function(err,row) {
		if(row)
		{ 
			for (var i = 0; i < row.length; i++) 
			{
				last_report = parseInt(row[i].id);
				const embedColor = 0xff0000;
			
				const logMessage = {
					embed: {
						title: row[i].report,
						color: embedColor,
						fields: [
							{ name: 'Time:', value: row[i].time, inline: true },
						],
					}
				};
				client.channels.cache.get(reportChannelID).send(logMessage);
			
			}
			if(!row.length && Bot_debug_mode)
				console.log(`[DEBUG] No New Reports Found Using ${last_report}`)
		}
		else 
		{

		}
	
	});

}
//-----------------------------[Debug]-----------------------------------
function toggle_debug() 
{
	if (Bot_debug_mode) 
	{
	  Bot_debug_mode = false;
	  console.log(`[DEBUG]: Debug Mode Disabled`);
	} 
	else 
	{
	  Bot_debug_mode = true;
	  console.log(`[DEBUG]: Debug Mode Enabled`);
	}
}

function GetPlayersOnline(msg) 
{
	var options = {
		host: 'play.indonex.my.id',
		port: '7777'
	}
	//console.log(options.host)
	query(options, function (error, response) {
		if(error)
		{
			console.log(error)
			const embedColor = 0xff0000;
			
			const logMessage = {
				embed: {
					title: 'Tunggu sebentar , gw berusaha me load stats server',
					color: embedColor,
					fields: [
						{ name: 'Error:', value: error, inline: true },
					],
				}
			}
			msg.channel.send(logMessage)
			
		}    
		else
		{   
			var str = "Server Info";
			var value = str.concat(' IP: ',response['address'],' Players Online: ',response['online'],'/',response['maxplayers']); 
			const embedColor = 0x00ff00;

			const logMessage = {
				embed: {
					title: 'Information Server INDONEX DM',
					color: embedColor,
					fields: [
						{ name: 'Server IP', value: response['address'], inline: true },
						{ name: 'Players Online', value: response['online'], inline: true },
						{ name: 'Max Players', value: response['maxplayers'], inline: true },
					],
				}
			}
			msg.channel.send(logMessage)
			if(Bot_debug_mode)
				console.log(value)
		}    
	})

}

function uBAN(msg,params)
{
	const member = msg.member;
	permcheck = (member.roles.cache.some((role) => role.name === "IDM Team Administrator"));
	if (params && permcheck) 
    {
		var sqlq;
		if(!isNaN(params))
		sqlq = `SELECT * FROM ban WHERE banName = '${params}' LIMIT 1`;
		else sqlq = `SELECT * FROM ban WHERE banName = '${params}' LIMIT 1`;

		db.query(sqlq,
		[], function(err,row) {
		   if(row)
		   { 	if(Bot_debug_mode)
					console.log(sqlq);
				if(row.length)
				{
					if(Bot_debug_mode)
						console.log(`[DEBUG]BAN id:${parseInt(row[0].banName)}`);
					uBAN_Process(row[0].banName, msg);
					
				}
				else
				client.channels.cache.get(adminCmdsChannelID).send("No ban found !!!");   
		   }
		   else 
			   console.log(`[ERROR]SQL Error(uBAN):${err}`);
	   
	   	});
  
	} else if (!permcheck) {
		const sukses = 'ERROR';
		// Jika pengguna tidak memiliki role "Admin", kirim pesan error di Discord
		const embedColor = 0xff0000;
		const logMessage = {
		  embed: {
			title: `**Error**`,
			color: embedColor,
			fields: [
			  { name: 'Anda tidak memiliki izin untuk melakukan perintah ini.', value:`${sukses}`, inline: true },
			],
		  },
		};
		msg.channel.send(logMessage);
	} else {
		msg.channel.send("Usage : !unbanned [InGame-Name].");
	}
	
}

function uBAN_Process(banname, msg)
{
	const sukses = 'SUCCESS';
	var sqlq;
	sqlq = `DELETE FROM ban WHERE banName = '${banname}'`;
		
	db.query(sqlq,
	[], function(err,row) {
		if(row)
		{ 	
			if(Bot_debug_mode)
				console.log(sqlq);
			const embedColor = 0xffff00;
			const logMessage = {
				embed: {
					title: `**Admin Cmd **`,
					color: embedColor,
					fields: [
						{ name: 'Berhasil melakukan Unban player ', value: `${sukses}`, inline: true },
					],
				}
			}
			msg.channel.send(logMessage); 
		}
		else 
			console.log(`[ERROR]SQL Error(uBAN_Process):${err}`);
	   
	});
  
	
}

function disablecht(msg)
{
	const member = msg.member;
	permcheck = (member.roles.cache.some((role) => role.name === "IDM Team Administrator"));
	if (permcheck) 
    {
		const sqlq = "UPDATE `server-info` SET `serverChat` = false WHERE 1";

		db.query(sqlq, function(err, rows) {
		  if (err) {
			console.log(`[ERROR] SQL Error (updateServerChat): ${err}`);
			return;
		  }
		
		  console.log(`Server chat berhasil dimatikan!`);
		
		  if (Bot_debug_mode) {
			console.log(sqlq);
		  }
		
		  const gege = 'SUCCESS';
		  const embedColor = 0xffff00;
		  const logMessage = {
			embed: {
			  title: `**Admin Cmd **`,
			  color: embedColor,
			  fields: [
				{ name: 'Berhasil Mematikan server chat', value:`${gege}`, inline: true },
			  ],
			},
		  };
		  msg.channel.send(logMessage);
		});

	} else if (!permcheck) {
		const sukses = 'ERROR';
		// Jika pengguna tidak memiliki role "Admin", kirim pesan error di Discord
		const embedColor = 0xff0000;
		const logMessage = {
		  embed: {
			title: `**Error**`,
			color: embedColor,
			fields: [
			  { name: 'Anda tidak memiliki izin untuk melakukan perintah ini.', value:`${sukses}`, inline: true },
			],
		  },
		};
		msg.channel.send(logMessage);
	} else
	{

	}
	
}

function enablecht(msg)
{
	const member = msg.member;
	permcheck = (member.roles.cache.some((role) => role.name === "IDM Team Administrator"));
	if (permcheck) 
    {

		const sqlq = "UPDATE `server-info` SET `serverChat` = true WHERE 1";

		db.query(sqlq, function(err, rows) {
		  if (err) {
			console.log(`[ERROR] SQL Error (updateServerChat): ${err}`);
			return;
		  }
		
		  console.log(`Server chat berhasil diaktifkan!`);
		
		  if (Bot_debug_mode) {
			console.log(sqlq);
		  }
		
		  const gege = 'SUCCESS';
		  const embedColor = 0xffff00;
		  const logMessage = {
			embed: {
			  title: `**Admin Cmd **`,
			  color: embedColor,
			  fields: [
				{ name: 'Berhasil Mengaktifkan server chat', value:`${gege}`, inline: true },
			  ],
			},
		  };
		  msg.channel.send(logMessage);
		});
		
	} else if (!permcheck) {
		const sukses = 'ERROR';
		// Jika pengguna tidak memiliki role "Admin", kirim pesan error di Discord
		const embedColor = 0xff0000;
		const logMessage = {
		  embed: {
			title: `**Error**`,
			color: embedColor,
			fields: [
			  { name: 'Anda tidak memiliki izin untuk melakukan perintah ini.', value:`${sukses}`, inline: true },
			],
		  },
		};
		msg.channel.send(logMessage);
	} else
	{

	}
  
	
}

function disablereq(msg)
{
	permcheck = (member.roles.cache.some((role) => role.name === "IDM Team Administrator"));
	if (permcheck) 
    {
		const sqlq = "UPDATE `server-info` SET `serverRegistration` = false WHERE 1";

		db.query(sqlq, function(err, rows) {
		  if (err) {
			console.log(`[ERROR] SQL Error (updateServerChat): ${err}`);
			return;
		  }
		
		  console.log(`Server register berhasil dimatikan!`);
		
		  if (Bot_debug_mode) {
			console.log(sqlq);
		  }

		  const gege = 'SUCCESS';
		  const embedColor = 0xffff00;
		  const logMessage = {
			embed: {
			  title: `**Admin Cmd **`,
			  color: embedColor,
			  fields: [
				{ name: 'Berhasil Mematikan server register', value:`${gege}`, inline: true },
			  ],
			},
		  };
		  msg.channel.send(logMessage);
		});

	} else if (!permcheck) {
		const sukses = 'ERROR';
		// Jika pengguna tidak memiliki role "Admin", kirim pesan error di Discord
		const embedColor = 0xff0000;
		const logMessage = {
		  embed: {
			title: `**Error**`,
			color: embedColor,
			fields: [
			  { name: 'Anda tidak memiliki izin untuk melakukan perintah ini.', value:`${sukses}`, inline: true },
			],
		  },
		};
		msg.channel.send(logMessage);
	} else
	{

	}
	
}

function enablereg(msg)
{
	const member = msg.member;
	permcheck = (member.roles.cache.some((role) => role.name === "IDM Team Administrator"));
	if (permcheck) 
    {
		const sqlq = "UPDATE `server-info` SET `serverRegistration` = true WHERE 1";

		db.query(sqlq, function(err, rows) {
		  if (err) {
			console.log(`[ERROR] SQL Error (updateServerChat): ${err}`);
			return;
		  }
		
		  console.log(`Server register berhasil diaktifkan!`);
		
		  if (Bot_debug_mode) {
			console.log(sqlq);
		  }
		  
		  const gege = 'SUCCESS';
		  const embedColor = 0xffff00;
		  const logMessage = {
			embed: {
			  title: `**Admin Cmd **`,
			  color: embedColor,
			  fields: [
				{ name: 'Berhasil Mengaktifkan server register', value:`${gege}`, inline: true },
			  ],
			},
		  };
		  msg.channel.send(logMessage);
		});

	} else if (!permcheck) {
		const sukses = 'ERROR';
		// Jika pengguna tidak memiliki role "Admin", kirim pesan error di Discord
		const embedColor = 0xff0000;
		const logMessage = {
		  embed: {
			title: `**Error**`,
			color: embedColor,
			fields: [
			  { name: 'Anda tidak memiliki izin untuk melakukan perintah ini.', value:`${sukses}`, inline: true },
			],
		  },
		};
		msg.channel.send(logMessage);
	} else
	{

	}	
}

function setVIP(msg, params) {
	const member = msg.member;
	const permcheck = member.roles.cache.some((role) => role.name === "SENIOR ADMIN");
	if (params && permcheck) {
	  let sqlq;
	  if (!isNaN(params)) {
		sqlq = `SELECT * FROM user WHERE pID = '${params}' LIMIT 1`;
	  } else {
		sqlq = `SELECT * FROM user WHERE pName = '${params}' LIMIT 1`;
	  }
  
	  db.query(sqlq, [], function(err, row) {
		if (row) {
		  if (Bot_debug_mode) {
			console.log(sqlq);
		  }
		  if (row.length) {
			if (Bot_debug_mode) {
			  console.log(`[DEBUG]BAN id:${parseInt(row[0].pID)}`);
			}
			vip_Process(msg, row[0].pID);
		  } else {
			msg.channel.send("Player not found!!!");
		  }
		} else {
		  console.log(`[ERROR]SQL Error(setVIP):${err}`);
		}
	  });
	} else if (!permcheck) {
	  const sukses = "ERROR";
	  const embedColor = 0xff0000;
	  const logMessage = {
		embed: {
		  title: `**Error**`,
		  color: embedColor,
		  fields: [
			{
			  name: "You do not have permission to execute this command.",
			  value: `${sukses}`,
			  inline: true,
			},
		  ],
		},
	  };
	  msg.channel.send(logMessage);
	} else {
	  msg.channel.send("Usage : !setvip [InGame-Name].");
	}
}
  
function vip_Process(msg, user) {
	const gege = "SUCCESS";
	const sqlq = `UPDATE user SET pPremium = '1', pPremiumHours = '100' WHERE pID = '${user}'`;
  
	db.query(sqlq, [], function(err, row) {
	  if (row) {
		if (Bot_debug_mode) {
		  console.log(sqlq);
		}
		const embedColor = 0xffff00;
		const logMessage = {
		  embed: {
			title: `**Admin Cmd **`,
			color: embedColor,
			fields: [
			  {
				name: "Successfully set Premium status for the player",
				value: `${gege}`,
				inline: true,
			  },
			],
		  },
		};
		msg.channel.send(logMessage);
	  } else {
		console.log(`[ERROR]SQL Error(vip_Process):${err}`);
	  }
	});
}
  

function delVIP(msg, params) {
	const member = msg.member;
	const permcheck = member.roles.cache.some((role) => role.name === "SENIOR ADMIN");
	
	if (params && permcheck) {
	  let sqlq;
	  
	  if (!isNaN(params)) {
		sqlq = `SELECT * FROM user WHERE pID = '${params}' LIMIT 1`;
	  } else {
		sqlq = `SELECT * FROM user WHERE pName = '${params}' LIMIT 1`;
	  }
  
	  db.query(sqlq, [], function (err, row) {
		if (row) {
		  if (Bot_debug_mode) console.log(sqlq);
		  
		  if (row.length) {
			if (Bot_debug_mode) console.log(`[DEBUG]DEL VIP id:${parseInt(row[0].pID)}`);
			delvip_Process(row[0].pID, msg);
		  } else {
			client.channels.cache.get(adminCmdsChannelID).send("Player tidak ditemukan, mohon periksa kembali username-nya.");
		  }
		} else {
		  console.log(`[ERROR]SQL Error(delVIP): ${err}`);
		}
	  });
	} else if (!permcheck) {
	  const sukses = "ERROR";
	  const embedColor = 0xff0000;
	  const logMessage = {
		embed: {
		  title: "**Error**",
		  color: embedColor,
		  fields: [
			{
			  name: "Anda tidak memiliki izin untuk melakukan perintah ini.",
			  value: `${sukses}`,
			  inline: true,
			},
		  ],
		},
	  };
	  msg.channel.send(logMessage);
	} else {
	  msg.channel.send("Usage: !delVIP [InGame-Name]");
	}
}
  
function delvip_Process(user, msg) {
	const param2 = "SUCCESS";
	const sqlq = `UPDATE user SET pPremium = '0', pPremiumHours = '0' WHERE pID = '${user}'`;
  
	db.query(sqlq, [], function (err, row) {
	  if (row) {
		if (Bot_debug_mode) console.log(sqlq);
		const embedColor = 0xffff00;
		const logMessage = {
		  embed: {
			title: "**Admin Cmd**",
			color: embedColor,
			fields: [
			  {
				name: "Berhasil menghapus Premium Player",
				value: `${param2}`,
				inline: true,
			  },
			],
		  },
		};
		msg.channel.send(logMessage);
	  } else {
		console.log(`[ERROR]SQL Error(delvip_Process): ${err}`);
	  }
	});
}
  

function sBAN(msg,params)
{
	permcheck = (msg.channel.id === playerCmdsChannelID) ? true : false;
	if (params && permcheck) 
    {
		var sqlq;
		if(!isNaN(params))
			sqlq = `SELECT * FROM user WHERE  pName = '${params}' LIMIT 1`;
		else sqlq = `SELECT * FROM user WHERE pName = '${params}' LIMIT 1`;

		db.query(sqlq,
		[], function(err,row) {
		   if(row)
		   { 
				if(row.length)
				{
					if(Bot_debug_mode)
						console.log(`[DEBUG]Ban ID:${parseInt(row[0].pName)}`);
					const embedColor = 0xffff00;
					const logMessage = {
						embed: {
							title: `**STATUS IN GAME ${row[0].pName}**`,
							color: embedColor,
							fields: [
								{ name: 'ALL Kills', value: row[0].pKills, inline: true },
								{ name: 'ALL Deaths', value: row[0].pDeaths, inline: true },
								{ name: 'Money', value: row[0].pMoney, inline: true },
								{ name: 'Max Killstreak', value: row[0].pMaxKS, inline: true },
								{ name: 'Day Kills', value: row[0].pDayKills, inline: true },
								{ name: 'Day Deaths', value: row[0].pDayDeaths, inline: true },
								{ name: 'Arena Kills', value: row[0].pArenaKills, inline: true },
								{ name: 'Arena Deaths', value: row[0].pArenaDeaths, inline: true },
								{ name: 'Duel Wins', value: row[0].pDuelWins, inline: true },
								{ name: 'Duel Defeats', value: row[0].pDuelDefeats, inline: true },
								{ name: 'Versus Wins', value: row[0].pVersusWins, inline: true },
								{ name: 'Versus Defeats', value: row[0].pVersusDefeats, inline: true },
								{ name: 'Month Kills', value: row[0].pMonthKills, inline: true },
								{ name: 'Last Login ', value: row[0].pLastLogin, inline: true },
							],
						}
					}
					client.channels.cache.get(playerCmdsChannelID).send(logMessage);
				}
				else
				client.channels.cache.get(playerCmdsChannelID).send("Nickname salah (Akun tidak ada)!!!"); 
		   }
		   else
		   console.log(`[ERROR]SQL Error(ADMcheck):${err}`);
	   
	   	});
	
	} else if (!permcheck) {
		msg.reply("Jangan Pakai cmd bot di sini ajg!");
	} else {
		msg.channel.send("Usage : !stats [InGame-Name].");
	}
	
}

function getToppRich(msg)
{
	permcheck = (msg.channel.id === playerCmdsChannelID) ? true : false;
	if (permcheck) 
    {
		var sqlq;
		
		sqlq = "SELECT `pMoney`, `pName` FROM `user` ORDER BY `pMoney` DESC LIMIT 5";	

		db.query(sqlq,
		[], function(err,row) {
			if(row)
			{ 
				if(row.length)
				{
					let i = 0,  pName="", pMoney="";

					for (; i < row.length; i++) {
						pMoney += `${row[i].pName} Money : ${row[i].pMoney}\n`;
					}
					

					const embedColor = 0xffff00;
			
					const logMessage = {
						embed: {
							title: `INDONEX DM STATS`,
							color: embedColor,
							fields: [
								{ name: 'TOP 5 Rich Player', value: pMoney, inline: true },
							],
						}
					}
					client.channels.cache.get(playerCmdsChannelID).send(logMessage);
				}
				else
				client.channels.cache.get(playerCmdsChannelID).send("Unknow top rich !!!");   
			}
		
		});

	} else if (!permcheck) {
		msg.reply("Jangan Pakai cmd bot di sini ajg !");
	} else
	{

	}
	
}

function getTopversus(msg)
{
	permcheck = (msg.channel.id === playerCmdsChannelID) ? true : false;
	if (permcheck) 
    {
		var sqlq;
		
		sqlq = "SELECT `pVersusWins`, `pName` FROM `user` ORDER BY `pVersusWins` DESC LIMIT 5";	

		db.query(sqlq,
		[], function(err,row) {
			if(row)
			{ 
				if(row.length)
				{
					let i = 0,  pName="", pVersusWins="";

					for (; i < row.length; i++) {
						pVersusWins += `${row[i].pName} VersusWins : ${row[i].pVersusWins}\n`;
					}
					

					const embedColor = 0xffff00;
			
					const logMessage = {
						embed: {
							title: `INDONEX DM STATS`,
							color: embedColor,
							fields: [
								{ name: 'TOP 5 Versus', value: pVersusWins, inline: true },
							],
						}
					}
					client.channels.cache.get(playerCmdsChannelID).send(logMessage);
				}
				else
				client.channels.cache.get(playerCmdsChannelID).send("Unknow top versus !!!");   
			}
		
		});

	} else if (!permcheck) {
		msg.reply("Jangan Pakai cmd bot di sini ajg !");
	} else
	{

	}
	
}

function getTopdeath(msg)
{
	permcheck = (msg.channel.id === playerCmdsChannelID) ? true : false;
	if (permcheck) 
    {
		var sqlq;
		
		sqlq = "SELECT `pDeaths`, `pName` FROM `user` ORDER BY `pDeaths` DESC LIMIT 5";	

		db.query(sqlq,
		[], function(err,row) {
			if(row)
			{ 
				if(row.length)
				{
					let i = 0,  pName="", pDeaths="";

					for (; i < row.length; i++) {
						pDeaths += `${row[i].pName} Death : ${row[i].pDeaths}\n`;
					}
					

					const embedColor = 0xffff00;
			
					const logMessage = {
						embed: {
							title: `INDONEX DM STATS`,
							color: embedColor,
							fields: [
								{ name: 'Top 5 Noob Player', value: pDeaths, inline: true },
							],
						}
					}
					client.channels.cache.get(playerCmdsChannelID).send(logMessage);
				}
				else
				client.channels.cache.get(playerCmdsChannelID).send("Unknow topdeath !!!");   
			}
		
		});

	} else if (!permcheck) {
		msg.reply("Jangan Pakai cmd bot di sini ajg !");
	} else
	{

	}
	
}

function getTopduel(msg)
{
	permcheck = (msg.channel.id === playerCmdsChannelID) ? true : false;
	if (permcheck) 
    {
		var sqlq;
		
		sqlq = "SELECT `pDuelWins`, `pName` FROM `user` ORDER BY `pDuelWins` DESC LIMIT 5";	

		db.query(sqlq,
		[], function(err,row) {
			if(row)
			{ 
				if(row.length)
				{
					let i = 0,  pName="", pDuelWins="";

					for (; i < row.length; i++) {
						pDuelWins += `${row[i].pName} DuelWins : ${row[i].pDuelWins}\n`;
					}
					

					const embedColor = 0xffff00;
			
					const logMessage = {
						embed: {
							title: `INDONEX DM STATS`,
							color: embedColor,
							fields: [
								{ name: 'Top 5 Duel Wins', value: pDuelWins, inline: true },
							],
						}
					}
					client.channels.cache.get(playerCmdsChannelID).send(logMessage);
				}
				else
				client.channels.cache.get(playerCmdsChannelID).send("Unknow top duel !!!");   
			}
		
		});

	} else if (!permcheck) {
		msg.reply("Jangan Pakai cmd bot di sini ajg !");
	} else
	{

	}
	
}

function getTopkKill(msg)
{
	permcheck = (msg.channel.id === playerCmdsChannelID) ? true : false;
	if (permcheck) 
    {
		var sqlq;
		
		sqlq = "SELECT `pKills`, `pName` FROM `user` ORDER BY `pKills` DESC LIMIT 5";	

		db.query(sqlq,
		[], function(err,row) {
			if(row)
			{ 
				if(row.length)
				{
					let i = 0,  pName="", pKills="";

					for (; i < row.length; i++) {
						pKills += `${row[i].pName} Kills : ${row[i].pKills}\n`;
					}
					

					const embedColor = 0xffff00;
			
					const logMessage = {
						embed: {
							title: `INDONEX DM STATS`,
							color: embedColor,
							fields: [
								{ name: 'Top 5 Leaderboard', value: pKills, inline: true },
							],
						}
					}
					client.channels.cache.get(playerCmdsChannelID).send(logMessage);
				}
				else
				client.channels.cache.get(playerCmdsChannelID).send("Unknow top leaderboard !!!");   
			}
		
		});

	} else if (!permcheck) {
		msg.reply("Jangan Pakai cmd bot di sini ajg !");
	} else
	{

	}
	
}

const helpinfo = (msg) => {
	if (!msg.guild) 
	{
		msg.reply("This command can only be used in a guild.");
		return;
	}
	const embedColor = 0xffff00;
	pcmds = `\`\`\`${botChar}online ${botChar}topkill ${botChar}toprich ${botChar}topversus ${botChar}topduel ${botChar}noob ip  ${botChar}helpme\`\`\``;
	acmds = `\`\`\`${botChar}setvip ${botChar}hapusvip ${botChar}chaton ${botChar}chatoff ${botChar}registeron ${botChar}registeroff ${botChar}unbanned\`\`\``;
    const logMessage = {
        embed: {
            title: `Discord Bot INDONEX Help Info`,
            color: embedColor,
            fields: [
				{ name: 'Player Cmds', value: pcmds, inline: true },
				{ name: 'Admin Cmds', value: acmds, inline: true },
            ],
        }
    }

	msg.channel.send(logMessage);

};


//______________________[COMMAND PROCESSOR]__________________________________
//@audit-ok Commands

client.on('message', msg => {

	//------------------------------[Medthod 1 For cmds]--------------------------------
    if (msg.content === 'halo') 
    {

        msg.reply(`Halo selamat datang di indonex [${Community_Tag}] Bot`);

    }
	if (msg.content === '!cekping') {
        const startTime = Date.now();
        msg.channel.send('Pong!').then(sentMessage => {
            const endTime = Date.now();
            sentMessage.edit(`Pong! Latency: ${endTime - startTime}ms`);
        });
	}

    if (msg.content === 'ip') 
    {

        msg.reply(` IP SERVER : ${Samp_IP}:7777`);
 
    }  
    //------------------------------[Medthod 2]-------------------------------------------
    if (msg.content.charAt(0) === botChar) {
		const request = msg.content.substr(1);
		let command, parameters = [];

		if (request.indexOf(" ") !== -1) {
			command = request.substr(0, request.indexOf(" "));
			parameters = request.split(" ");
			parameters.shift();
		} else {
			command = request;
		}
		
		switch (command.toLowerCase()) {
			case "online":
				GetPlayersOnline(msg);
				break;
			case "topkill":
				getTopkKill(msg);
				break;
			case "toprich":
				getToppRich(msg)
				break;
			case "chaton":
				enablecht(msg)
				break;
			case "chatoff":
				disablecht(msg)
				break;
			case "registeron":
				enablereg(msg)
				break;
			case "registeroff":
				disablereq(msg)
				break;
			case "debug":
				toggle_debug()
				break;
			case "helpme":
				helpinfo(msg);
				break;
			case "setvip":
				setVIP(msg, parameters.join(" "));
				break;
			case "topduel":
				getTopduel(msg, parameters.join(" "));
				break;
			case "topversus":
				getTopversus(msg, parameters.join(" "));
				break;
			case "noob":
				getTopdeath(msg, parameters.join(" "));
				break;
			case "hapusvip":
				delVIP(msg, parameters.join(" "));
				break;
			case "unbanned":
				uBAN(msg, parameters.join(" "));
				break;
			case "stats":
				sBAN(msg, parameters.join(" "));
				break; 	
			default:
				
		}
	} else {
		if (msg.channel.type === "dm") {
			if (msg.author.id === isSettingFormUp) {
				appNewForm.push(msg.content);
			} else {
				const user = usersApplicationStatus.find(user => user.id === msg.author.id);

				if (user && msg.content) {
					user.answers.push(msg.content);
					user.currentStep++;

					if (user.currentStep >= applicationQuestions.length) {
						applicationFormCompleted(user);
						msg.author.send("Congratulations your application has been sent!");
					} else {
						msg.author.send(applicationQuestions[user.currentStep]);
					}
				}
			}
		}
	}  

});
//_____________________________________[END-SAMP CMDS]____________________________________________________________________
 

//====================== BOT TOKEN FROM ENV VAIABLE ===================================

client.login('MTAyNDYxMTgyNTgxMzMwNzQzMw.GvE_Hx.e09RnEg7zFZrtSBo50pEVlc6IG9pwnNjY5LjM0');//BOT_TOKEN is the Client Secret

//=====================================================================================
